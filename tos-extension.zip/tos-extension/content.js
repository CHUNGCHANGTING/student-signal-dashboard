// 下班鴿 TOS 帶單助手 v1.1
// 接收來自下班鴿系統的 URL 參數，自動在 Schwab TOS 填入訂單

window.addEventListener('load', () => {
    const urlParams = new URLSearchParams(window.location.search);
    const symbol = urlParams.get('symbol');
    const trade  = urlParams.get('trade');   // e.g. SELL PUT 555/BUY PUT 550
    const expiry = urlParams.get('expiry');  // e.g. 2026-04-22
    const source = urlParams.get('source');  // 'chilldove'

    if (symbol && source === 'chilldove') {
        console.log('🕊️ 下班鴿助手啟動！標的：' + symbol);
        executeTradeFlow(symbol, trade, expiry);
        if (trade && expiry) showTradingHelper(symbol, trade, expiry);
    }
});

// ─── 等待 DOM 元素出現 ───────────────────────────────────────────────────────
function waitForElement(selector, maxWait = 12000) {
    return new Promise((resolve, reject) => {
        let elapsed = 0;
        const timer = setInterval(() => {
            const el = document.querySelector(selector);
            if (el) { clearInterval(timer); resolve(el); }
            elapsed += 500;
            if (elapsed >= maxWait) {
                clearInterval(timer);
                console.error('🕊️ 找不到元素：' + selector);
                reject('Timeout');
            }
        }, 500);
    });
}

// ─── 核心下單流程 ─────────────────────────────────────────────────────────────
async function executeTradeFlow(symbol, trade, expiry) {
    try {
        // 階段 1：填入標的
        const inputBox = await waitForElement('input[placeholder*="代號"], input[placeholder*="symbol"], input[placeholder*="Symbol"]');
        inputBox.value = symbol;
        inputBox.dispatchEvent(new Event('input',  { bubbles: true }));
        inputBox.dispatchEvent(new Event('change', { bubbles: true }));
        await delay(800);
        inputBox.dispatchEvent(new KeyboardEvent('keydown', { key: 'Enter', keyCode: 13, bubbles: true }));
        const form = inputBox.closest('form');
        if (form) form.dispatchEvent(new Event('submit', { bubbles: true, cancelable: true }));
        console.log('🕊️ 標的送出：' + symbol);

        if (!trade || !expiry) return;

        // 階段 2：展開選擇權鏈
        const chainBtn = await waitForElement('button[aria-label="顯示期權鏈"], button[aria-label="Show Options Chain"]');
        if (chainBtn.getAttribute('aria-expanded') !== 'true') {
            chainBtn.click();
            await delay(1200);
        }

        // 階段 3：點擊到期日列
        const dateParts = expiry.split('-');
        const year  = dateParts[0];
        const month = parseInt(dateParts[1], 10);
        const day   = parseInt(dateParts[2], 10);
        const targetDateStr = `${year}年${month}月${day}日`;
        console.log('🕊️ 尋找到期日：' + targetDateStr);

        await waitForElement('button[data-testid="expiration-row-expand-button"]');
        const dateBtns = document.querySelectorAll('button[data-testid="expiration-row-expand-button"]');
        let targetDateBtn = null;
        for (const btn of dateBtns) {
            if (btn.innerText.includes(targetDateStr)) { targetDateBtn = btn; break; }
        }
        if (!targetDateBtn) { console.error('🕊️ 找不到日期：' + targetDateStr); return; }
        if (targetDateBtn.getAttribute('aria-expanded') !== 'true') {
            targetDateBtn.scrollIntoView({ behavior: 'smooth', block: 'center' });
            await delay(500);
            targetDateBtn.click();
            await delay(2000);
        }

        // 階段 4：逐腳位點擊
        const legs = trade.split('/').map(t => t.trim());
        await delay(3000); // 等待報價渲染

        for (let i = 0; i < legs.length; i++) {
            const parts      = legs[i].split(' ').filter(p => p);
            const action     = parts[0].toUpperCase(); // BUY / SELL
            const type       = parts[1].toUpperCase(); // PUT / CALL
            const strike     = parseFloat(parts[2]);
            const typeClass  = type   === 'PUT'  ? '.cell.put'  : '.cell.call';
            const actionClass= action === 'SELL' ? '.bid'       : '.ask';

            const selectors = [
                `td${typeClass}${actionClass}[data-testid^="data-cell-td-${strike}-"]`,
                `td${typeClass}${actionClass}[data-testid^="data-cell-td-${strike.toFixed(1)}-"]`,
                `td${typeClass}${actionClass}[data-testid^="data-cell-td-${strike.toFixed(0)}-"]`
            ];

            let cell = null;
            for (const sel of selectors) { cell = document.querySelector(sel); if (cell) break; }

            if (cell) {
                cell.scrollIntoView({ behavior: 'smooth', block: 'center', inline: 'center' });
                await delay(800);
                const btn = cell.querySelector('button');
                if (btn) {
                    const opts = { bubbles: true, cancelable: true, ctrlKey: i > 0, view: window, which: 1 };
                    btn.dispatchEvent(new PointerEvent('pointerdown', opts));
                    btn.dispatchEvent(new MouseEvent('mousedown', opts));
                    await delay(100);
                    btn.dispatchEvent(new PointerEvent('pointerup', opts));
                    btn.dispatchEvent(new MouseEvent('mouseup', opts));
                    btn.click();
                    console.log('🕊️ 點擊成功：' + legs[i]);
                    await delay(1000);
                }
            } else {
                console.error('🕊️ 找不到腳位：' + type + ' ' + strike);
            }
        }
        console.log('🕊️ 所有腳位完成！');

    } catch(e) {
        console.log('🕊️ 流程中斷：', e);
    }
}

function delay(ms) { return new Promise(r => setTimeout(r, ms)); }

// ─── 右下角提示卡 ──────────────────────────────────────────────────────────────
function showTradingHelper(symbol, trade, expiry) {
    const existing = document.getElementById('chilldove-helper');
    if (existing) existing.remove();

    const helper = document.createElement('div');
    helper.id = 'chilldove-helper';
    const formattedTrade = trade.replace(/\//g, '<br>👉 ');
    helper.innerHTML = `
        <div style="font-family:'Segoe UI',sans-serif;background:#0f172a;border:2px solid #01696f;border-radius:14px;padding:20px;color:white;box-shadow:0 10px 40px rgba(0,0,0,0.8);width:320px">
            <div style="display:flex;justify-content:space-between;align-items:center;border-bottom:1px solid #334155;padding-bottom:10px;margin-bottom:14px">
                <h3 style="margin:0;color:#01696f;font-size:15px;font-weight:700">🕊️ 下班鴿帶單助手</h3>
                <span style="font-size:18px">🚀</span>
            </div>
            <p style="margin:0 0 6px;font-size:13px;color:#94a3b8">操作標的：<strong style="color:white;font-size:17px;margin-left:4px">${symbol}</strong></p>
            <p style="margin:0 0 12px;font-size:13px;color:#94a3b8">到期日：<strong style="color:#fcd34d;font-size:14px;margin-left:4px">${expiry}</strong></p>
            <div style="background:#1e293b;padding:14px;border-radius:8px;border-left:4px solid #01696f">
                <p style="margin:0;font-size:15px;font-weight:700;color:#a7f3d0;line-height:1.7;font-family:monospace">
                    👉 ${formattedTrade}
                </p>
            </div>
            <div style="margin-top:12px;font-size:11px;color:#64748b;text-align:center">正在自動填入腳位，請稍候...</div>
            <button id="chilldove-close-btn" style="margin-top:14px;width:100%;padding:10px;background:#1e3a3a;border:1px solid #01696f;color:#a7f3d0;border-radius:7px;cursor:pointer;font-weight:600;font-size:13px">
                ✅ 我已確認下單（關閉提示）
            </button>
        </div>`;
    helper.style.cssText = 'position:fixed;bottom:40px;right:40px;z-index:99999999';
    document.body.appendChild(helper);
    document.getElementById('chilldove-close-btn').onclick = () => helper.remove();
}
