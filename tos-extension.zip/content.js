// 下班鴿 TOS 帶單助手 v1.5
// 架構完全參照永日魚，加入 localStorage 備援處理登入跳轉

// ─── 方式 1：已登入狀態 — 直接從 URL 讀參數（永日魚原版邏輯）──────────────
window.addEventListener('load', () => {
    const urlParams = new URLSearchParams(window.location.search);
    const symbol = urlParams.get('symbol');
    const trade  = urlParams.get('trade');
    const expiry = urlParams.get('expiry');
    const source = urlParams.get('source');

    // 有 URL 參數的情況（直接帶入，永日魚相同邏輯）
    if (symbol && trade && expiry) {
        console.log('🕊️ 下班鴿助手（URL模式）啟動！標的：' + symbol);
        // 同時備份到 localStorage，以防萬一
        try {
            localStorage.setItem('cd_task', JSON.stringify({
                symbol, trade, expiry, ts: Date.now()
            }));
        } catch(e) {}
        showTradingHelper(symbol, trade, expiry);
        executeTradeFlow(symbol, trade, expiry);
        return;
    }

    // ─── 方式 2：未登入跳轉後回來 — 從 localStorage 讀參數 ─────────────────
    try {
        const raw = localStorage.getItem('cd_task');
        if (!raw) return;
        const task = JSON.parse(raw);
        // 超過 10 分鐘視為過期
        if (Date.now() - task.ts > 10 * 60 * 1000) {
            localStorage.removeItem('cd_task');
            return;
        }
        if (!task.symbol || !task.trade) return;

        console.log('🕊️ 下班鴿助手（localStorage模式）啟動！標的：' + task.symbol);
        localStorage.removeItem('cd_task');
        showTradingHelper(task.symbol, task.trade, task.expiry);
        executeTradeFlow(task.symbol, task.trade, task.expiry);
    } catch(e) {}
});

// ─── 等待元素出現（完全複製永日魚）────────────────────────────────────────────
function waitForElement(selector, maxWait = 10000) {
    return new Promise((resolve, reject) => {
        let timeSpent = 0;
        const interval = setInterval(() => {
            const el = document.querySelector(selector);
            if (el) {
                clearInterval(interval);
                resolve(el);
            }
            timeSpent += 500;
            if (timeSpent >= maxWait) {
                clearInterval(interval);
                console.error('🕊️ 找不到元素: ' + selector);
                reject('Timeout');
            }
        }, 500);
    });
}

// ─── 核心下單流程（完全複製永日魚邏輯，只換品牌文字）──────────────────────────
async function executeTradeFlow(symbol, trade, expiry) {
    try {
        // --- 階段 1：填寫標的並送出 ---
        const inputBox = await waitForElement('input[placeholder*="代號"]');
        inputBox.value = symbol;
        inputBox.dispatchEvent(new Event('input', { bubbles: true }));
        inputBox.dispatchEvent(new Event('change', { bubbles: true }));

        await new Promise(r => setTimeout(r, 800));

        inputBox.dispatchEvent(new KeyboardEvent('keydown', { key: 'Enter', keyCode: 13, bubbles: true }));
        const form = inputBox.closest('form');
        if (form) form.dispatchEvent(new Event('submit', { bubbles: true, cancelable: true }));

        console.log('🕊️ 標的送出完成');
        updateStatus('⏳ 展開選擇權鏈...');

        if (!trade || !expiry) return;

        // --- 階段 2：展開選擇權鏈 ---
        const optionsChainBtn = await waitForElement('button[aria-label="顯示期權鏈"]');
        if (optionsChainBtn.getAttribute('aria-expanded') !== 'true') {
            optionsChainBtn.click();
            console.log('🕊️ 已展開期權鏈');
            await new Promise(r => setTimeout(r, 1000));
        }
        updateStatus('⏳ 尋找到期日...');

        // --- 階段 3：找到期日 ---
        const dateParts = expiry.split('-');
        const year  = dateParts[0];
        const month = parseInt(dateParts[1], 10);
        const day   = parseInt(dateParts[2], 10);
        const targetDateStr = `${year}年${month}月${day}日`;

        console.log('🕊️ 尋找日期: ' + targetDateStr);

        await waitForElement('button[data-testid="expiration-row-expand-button"]');

        const dateButtons = document.querySelectorAll('button[data-testid="expiration-row-expand-button"]');
        let dateRowBtn = null;
        for (let btn of dateButtons) {
            if (btn.innerText.includes(targetDateStr)) {
                dateRowBtn = btn;
                break;
            }
        }

        if (dateRowBtn) {
            if (dateRowBtn.getAttribute('aria-expanded') !== 'true') {
                dateRowBtn.scrollIntoView({ behavior: 'smooth', block: 'center' });
                await new Promise(r => setTimeout(r, 500));
                dateRowBtn.click();
                console.log('🕊️ 已展開日期: ' + targetDateStr);
                await new Promise(r => setTimeout(r, 2000));
            }
        } else {
            console.error('🕊️ 找不到日期: ' + targetDateStr);
            updateStatus('⚠️ 找不到到期日 ' + expiry);
            return;
        }

        // --- 階段 4：逐腳位點擊（永日魚原版邏輯）---
        console.log('🕊️ 執行策略: ' + trade);
        updateStatus('⏳ 填入腳位...');
        await new Promise(r => setTimeout(r, 3000));

        const legs = trade.split('/').map(t => t.trim());

        for (let i = 0; i < legs.length; i++) {
            const leg = legs[i];
            const parts = leg.split(' ').filter(p => p !== '');
            const action = parts[0].toUpperCase();
            const type   = parts[1].toUpperCase();
            const strikePrice = parseFloat(parts[2]);

            console.log('🕊️ 鎖定腳位: ' + leg);

            let typeClass   = (type   === 'PUT')  ? '.cell.put'  : '.cell.call';
            let actionClass = (action === 'SELL') ? '.bid'       : '.ask';

            const possibleSelectors = [
                `td${typeClass}${actionClass}[data-testid^="data-cell-td-${strikePrice}-"]`,
                `td${typeClass}${actionClass}[data-testid^="data-cell-td-${strikePrice.toFixed(1)}-"]`,
                `td${typeClass}${actionClass}[data-testid^="data-cell-td-${strikePrice.toFixed(0)}-"]`
            ];

            let targetClickCell = null;
            for (let sel of possibleSelectors) {
                targetClickCell = document.querySelector(sel);
                if (targetClickCell) break;
            }

            if (targetClickCell) {
                console.log('🕊️ 鎖定成功: ' + targetClickCell.getAttribute('data-testid'));
                targetClickCell.scrollIntoView({ behavior: 'smooth', block: 'center', inline: 'center' });
                await new Promise(r => setTimeout(r, 800));

                const orderBtn = targetClickCell.querySelector('button');
                const isCtrl   = (i > 0);

                if (orderBtn) {
                    const eventOpts = { bubbles: true, cancelable: true, ctrlKey: isCtrl, view: window, which: 1 };
                    orderBtn.dispatchEvent(new PointerEvent('pointerdown', eventOpts));
                    orderBtn.dispatchEvent(new MouseEvent('mousedown',    eventOpts));
                    await new Promise(r => setTimeout(r, 100));
                    orderBtn.dispatchEvent(new PointerEvent('pointerup', eventOpts));
                    orderBtn.dispatchEvent(new MouseEvent('mouseup',     eventOpts));
                    orderBtn.click();
                    console.log('🕊️ 點擊成功: ' + leg);
                    await new Promise(r => setTimeout(r, 1000));
                } else {
                    console.error('🕊️ 找到格子但無按鈕: ' + leg);
                }
            } else {
                console.error('🕊️ 找不到: ' + type + ' ' + strikePrice);
                updateStatus('⚠️ 找不到 ' + type + ' ' + strikePrice);
            }
        }

        updateStatus('✅ 完成！請確認並送出訂單');
        console.log('🕊️ 全部完成！');

    } catch (error) {
        console.log('🕊️ 流程中斷:', error);
        updateStatus('⚠️ 中斷，請手動操作');
    }
}

// ─── 右下角提示卡（參照永日魚樣式）──────────────────────────────────────────
function showTradingHelper(symbol, trade, expiry) {
    document.getElementById('chilldove-helper')?.remove();

    const helper = document.createElement('div');
    helper.id = 'chilldove-helper';
    const formattedTrade = trade.replace(/\//g, '<br>👉 ');

    helper.innerHTML = `
        <div style="font-family:'Segoe UI',Tahoma,Geneva,Verdana,sans-serif;background:#0f172a;border:2px solid #01696f;border-radius:12px;padding:20px;color:white;box-shadow:0 10px 30px rgba(0,0,0,0.8);width:320px;">
            <div style="display:flex;justify-content:space-between;align-items:center;border-bottom:1px solid #334155;padding-bottom:10px;margin-bottom:15px;">
                <h3 style="margin:0;color:#01696f;font-size:16px;font-weight:bold;">🕊️ 下班鴿帶單助手</h3>
                <button id="cd-close-x" style="background:none;border:none;color:#64748b;cursor:pointer;font-size:20px;padding:0;">×</button>
            </div>
            <p style="margin:0 0 8px;font-size:14px;color:#94a3b8;">操作標的：<strong style="color:white;font-size:18px;margin-left:5px;">${symbol}</strong></p>
            <p style="margin:0 0 15px;font-size:14px;color:#94a3b8;">選擇權到期：<strong style="color:#fcd34d;font-size:16px;margin-left:5px;">${expiry}</strong></p>
            <div style="background:#1e293b;padding:15px;border-radius:8px;border-left:4px solid #01696f;">
                <p style="margin:0;font-size:16px;font-weight:bold;color:#a7f3d0;line-height:1.6;font-family:monospace;">
                    👉 ${formattedTrade}
                </p>
            </div>
            <div id="cd-status" style="margin-top:12px;font-size:12px;color:#fbbf24;text-align:center;">⏳ 執行中...</div>
            <button id="cd-close-btn" style="margin-top:15px;width:100%;padding:10px;background:#334155;border:1px solid #475569;color:white;border-radius:6px;cursor:pointer;font-weight:bold;">
                我已送出訂單（關閉提示）
            </button>
        </div>
    `;

    helper.style.position = 'fixed';
    helper.style.bottom   = '40px';
    helper.style.right    = '40px';
    helper.style.zIndex   = '99999999';

    document.body.appendChild(helper);
    document.getElementById('cd-close-btn').addEventListener('click', () => helper.remove());
    document.getElementById('cd-close-x').addEventListener('click',   () => helper.remove());
}

function updateStatus(msg) {
    const el = document.getElementById('cd-status');
    if (!el) return;
    el.textContent = msg;
    el.style.color = msg.startsWith('✅') ? '#34d399' : msg.startsWith('⚠️') ? '#f87171' : '#fbbf24';
}
