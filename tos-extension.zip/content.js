// 下班鴿 TOS 帶單助手 v1.4
// 修正：TOS SPA 會清除 URL params，改用 localStorage 跨分頁傳參

(function() {
  const SYMBOL_SELECTORS = [
    'input[placeholder*="Symbol"]',
    'input[placeholder*="symbol"]',
    'input[placeholder*="代號"]',
    'input[placeholder*="尋找代號"]',
    '[data-testid="symbol-input"]',
    'input[aria-label*="Symbol"]',
    '.search-input input',
    'input.symbol-search'
  ].join(', ');

  // ─── Step 1: 從 URL 讀參數存到 localStorage（TOS 清除 URL 前先搶救）──────
  // 這段必須在頁面 JS 執行之前跑，所以放在 content_scripts 最頂層
  (function saveParams() {
    try {
      const p = new URLSearchParams(window.location.search);
      if (p.get('source') === 'chilldove' && p.get('symbol')) {
        const payload = {
          symbol: p.get('symbol'),
          trade:  p.get('trade')  || '',
          expiry: p.get('expiry') || '',
          ts: Date.now() // timestamp 防止舊任務重複執行
        };
        localStorage.setItem('cd_task', JSON.stringify(payload));
        console.log('🕊️ 參數搶救成功:', payload);
      }
    } catch(e) {}
  })();

  // ─── Step 2: 持續輪詢等 TOS 主介面出現，然後執行 ─────────────────────────
  let executed = false;
  let attempts = 0;

  const poller = setInterval(() => {
    if (executed) { clearInterval(poller); return; }
    if (++attempts > 120) { clearInterval(poller); return; } // 60 秒超時

    // 讀取任務
    let task = null;
    try {
      const raw = localStorage.getItem('cd_task');
      if (!raw) { clearInterval(poller); return; }
      task = JSON.parse(raw);
      // 超過 5 分鐘的任務視為過期
      if (Date.now() - task.ts > 5 * 60 * 1000) {
        localStorage.removeItem('cd_task');
        clearInterval(poller);
        return;
      }
    } catch(e) { clearInterval(poller); return; }

    // 偵測 TOS 主介面（symbol input 出現代表主介面已載入）
    const input = document.querySelector(SYMBOL_SELECTORS);
    if (!input) return; // 還在登入頁或載入中，繼續等

    // 找到了，執行
    executed = true;
    clearInterval(poller);
    localStorage.removeItem('cd_task'); // 清除，防止重複

    console.log('🕊️ 開始執行 | 標的:', task.symbol, '| 腳位:', task.trade);
    showTradingHelper(task.symbol, task.trade, task.expiry);
    executeTradeFlow(task.symbol, task.trade, task.expiry);

  }, 500);

})();

// ─────────────────────────────────────────────────────────────────────────────

function waitForElement(selector, maxWait = 15000) {
  return new Promise((resolve, reject) => {
    let elapsed = 0;
    const t = setInterval(() => {
      const el = document.querySelector(selector);
      if (el) { clearInterval(t); resolve(el); }
      elapsed += 500;
      if (elapsed >= maxWait) { clearInterval(t); reject('Timeout: ' + selector); }
    }, 500);
  });
}

function delay(ms) { return new Promise(r => setTimeout(r, ms)); }

// ─── 核心下單流程 ─────────────────────────────────────────────────────────────
async function executeTradeFlow(symbol, trade, expiry) {
  const SYMBOL_SEL = [
    'input[placeholder*="Symbol"]',
    'input[placeholder*="symbol"]',
    'input[placeholder*="代號"]',
    'input[placeholder*="尋找代號"]',
    '[data-testid="symbol-input"]',
    'input[aria-label*="Symbol"]'
  ].join(', ');

  try {
    updateStatus('⏳ 填入標的 ' + symbol + '...');

    // 1. 填入標的
    const inputBox = await waitForElement(SYMBOL_SEL, 10000);
    inputBox.focus();
    await delay(400);

    // React controlled input — 用 native setter 觸發
    const setter = Object.getOwnPropertyDescriptor(window.HTMLInputElement.prototype, 'value').set;
    setter.call(inputBox, symbol);
    inputBox.dispatchEvent(new Event('input',  { bubbles: true }));
    inputBox.dispatchEvent(new Event('change', { bubbles: true }));
    await delay(1000);
    inputBox.dispatchEvent(new KeyboardEvent('keydown', { key: 'Enter', keyCode: 13, bubbles: true }));
    const form = inputBox.closest('form');
    if (form) form.dispatchEvent(new Event('submit', { bubbles: true, cancelable: true }));
    await delay(500);
    console.log('🕊️ 標的送出:', symbol);

    if (!trade || !expiry) { updateStatus('✅ 標的已填入'); return; }

    // 2. 展開選擇權鏈
    updateStatus('⏳ 展開選擇權鏈...');
    const chainBtn = await waitForElement([
      'button[aria-label="顯示期權鏈"]',
      'button[aria-label="Show Options Chain"]',
      'button[aria-label="Options Chain"]',
      '[data-testid="options-chain-button"]',
      'button[aria-label*="ption"]'
    ].join(', '), 10000);
    if (chainBtn.getAttribute('aria-expanded') !== 'true') {
      chainBtn.click();
      await delay(1500);
    }

    // 3. 找到期日
    updateStatus('⏳ 尋找到期日 ' + expiry + '...');
    const [y, m, d] = expiry.split('-');
    const dateStr = `${y}年${parseInt(m)}月${parseInt(d)}日`;

    await waitForElement('button[data-testid="expiration-row-expand-button"]', 8000);
    await delay(600);
    let dateBtn = null;
    for (const btn of document.querySelectorAll('button[data-testid="expiration-row-expand-button"]')) {
      if (btn.innerText.includes(dateStr)) { dateBtn = btn; break; }
    }
    if (!dateBtn) {
      updateStatus('⚠️ 找不到 ' + expiry + '，請手動選擇');
      return;
    }
    if (dateBtn.getAttribute('aria-expanded') !== 'true') {
      dateBtn.scrollIntoView({ behavior: 'smooth', block: 'center' });
      await delay(600);
      dateBtn.click();
      await delay(2500);
    }

    // 4. 逐腳位點擊
    await delay(3000);
    const legs = trade.split('/').map(s => s.trim());
    for (let i = 0; i < legs.length; i++) {
      const parts  = legs[i].split(' ').filter(Boolean);
      const action = parts[0].toUpperCase(); // BUY/SELL
      const type   = parts[1].toUpperCase(); // PUT/CALL
      const strike = parseFloat(parts[2]);
      updateStatus(`⏳ 點擊 ${action} ${type} ${strike}...`);

      const tc = type   === 'PUT'  ? '.cell.put'  : '.cell.call';
      const ac = action === 'SELL' ? '.bid'       : '.ask';
      const tries = [
        `td${tc}${ac}[data-testid^="data-cell-td-${strike}-"]`,
        `td${tc}${ac}[data-testid^="data-cell-td-${strike.toFixed(1)}-"]`,
        `td${tc}${ac}[data-testid^="data-cell-td-${strike.toFixed(0)}-"]`,
        `td${tc}[data-testid^="data-cell-td-${strike}-"]`
      ];
      let cell = null;
      for (const sel of tries) { cell = document.querySelector(sel); if (cell) break; }

      if (cell) {
        cell.scrollIntoView({ behavior: 'smooth', block: 'center', inline: 'center' });
        await delay(800);
        const btn = cell.querySelector('button');
        if (btn) {
          const o = { bubbles: true, cancelable: true, ctrlKey: i > 0, view: window, which: 1 };
          btn.dispatchEvent(new PointerEvent('pointerdown', o));
          btn.dispatchEvent(new MouseEvent('mousedown', o));
          await delay(120);
          btn.dispatchEvent(new PointerEvent('pointerup', o));
          btn.dispatchEvent(new MouseEvent('mouseup', o));
          btn.click();
          console.log('🕊️ 點擊:', legs[i]);
          await delay(1200);
        }
      } else {
        updateStatus(`⚠️ 找不到 ${type} ${strike}，請手動點擊`);
        console.error('🕊️ 找不到腳位:', type, strike);
      }
    }
    updateStatus('✅ 完成！請確認訂單後送出');

  } catch(e) {
    updateStatus('⚠️ 中斷: ' + String(e).slice(0, 40));
    console.error('🕊️ 流程中斷:', e);
  }
}

// ─── 右下角提示卡 ─────────────────────────────────────────────────────────────
function showTradingHelper(symbol, trade, expiry) {
  document.getElementById('chilldove-helper')?.remove();
  const helper = document.createElement('div');
  helper.id = 'chilldove-helper';
  helper.style.cssText = 'position:fixed;bottom:30px;right:30px;z-index:2147483647';
  helper.innerHTML = `
    <div style="font-family:'Segoe UI',sans-serif;background:#0f172a;border:2px solid #01696f;
                border-radius:14px;padding:18px;color:white;box-shadow:0 10px 40px rgba(0,0,0,0.85);width:290px">
      <div style="display:flex;justify-content:space-between;align-items:center;
                  border-bottom:1px solid #1e3a3a;padding-bottom:8px;margin-bottom:12px">
        <span style="color:#01696f;font-size:14px;font-weight:700">🕊️ 下班鴿帶單助手</span>
        <button onclick="document.getElementById('chilldove-helper').remove()"
                style="background:none;border:none;color:#64748b;cursor:pointer;font-size:20px;line-height:1">×</button>
      </div>
      <div style="font-size:12px;color:#94a3b8;margin-bottom:4px">標的 <strong style="color:white;font-size:15px">${symbol}</strong>
        &nbsp;|&nbsp; 到期 <strong style="color:#fcd34d">${expiry}</strong></div>
      <div style="background:#1e293b;padding:10px 12px;border-radius:8px;border-left:3px solid #01696f;margin:10px 0;
                  font-family:monospace;font-size:13px;font-weight:700;color:#a7f3d0;line-height:1.8">
        ${trade.replace(/\//g, '<br>👉 ')}
      </div>
      <div id="cd-status" style="font-size:11px;color:#fbbf24;text-align:center;margin-bottom:10px">
        ⏳ 等待 TOS 介面...</div>
      <button onclick="document.getElementById('chilldove-helper').remove()"
              style="width:100%;padding:8px;background:#1e3a3a;border:1px solid #01696f;
                     color:#a7f3d0;border-radius:6px;cursor:pointer;font-weight:600;font-size:12px">
        ✅ 已確認下單（關閉）</button>
    </div>`;
  document.body.appendChild(helper);
}

function updateStatus(msg) {
  const el = document.getElementById('cd-status');
  if (!el) return;
  el.textContent = msg;
  el.style.color = msg.startsWith('✅') ? '#34d399' : msg.startsWith('⚠️') ? '#f87171' : '#fbbf24';
}
