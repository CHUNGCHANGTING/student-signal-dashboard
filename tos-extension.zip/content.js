// 下班鴿 TOS 帶單助手 v1.3
// 修正：SPA 不觸發 window.load，改用持續輪詢偵測主介面出現

(function() {
  const SELECTOR_SYMBOL_INPUT = [
    'input[placeholder*="Symbol"]',
    'input[placeholder*="symbol"]',
    'input[placeholder*="代號"]',
    '[data-testid="symbol-input"]',
    'input[aria-label*="Symbol"]',
    'input[aria-label*="symbol"]'
  ].join(', ');

  // ─── Step 1: 儲存 URL 參數（任何時候只要帶了 source=chilldove 就存）───────
  const p = new URLSearchParams(window.location.search);
  if (p.get('source') === 'chilldove' && p.get('symbol')) {
    sessionStorage.setItem('cd_symbol', p.get('symbol'));
    sessionStorage.setItem('cd_trade',  p.get('trade')  || '');
    sessionStorage.setItem('cd_expiry', p.get('expiry') || '');
    console.log('🕊️ 參數已儲存:', p.get('symbol'), p.get('trade'), p.get('expiry'));
  }

  // ─── Step 2: 持續輪詢，等 TOS 主介面出現後執行 ───────────────────────────
  let executed = false;
  let attempts = 0;
  const MAX_ATTEMPTS = 120; // 最多等 60 秒

  const poller = setInterval(() => {
    if (executed) { clearInterval(poller); return; }
    attempts++;
    if (attempts > MAX_ATTEMPTS) {
      clearInterval(poller);
      console.log('🕊️ 等待超時，請確認已登入 TOS');
      return;
    }

    const symbol  = sessionStorage.getItem('cd_symbol');
    const trade   = sessionStorage.getItem('cd_trade');
    const expiry  = sessionStorage.getItem('cd_expiry');
    if (!symbol) { clearInterval(poller); return; } // 沒有任務

    // 偵測 TOS 主介面是否已渲染（找 symbol input 欄位）
    const input = document.querySelector(SELECTOR_SYMBOL_INPUT);
    if (!input) return; // 還沒出現，繼續等

    // 找到了！執行下單流程
    executed = true;
    clearInterval(poller);
    console.log('🕊️ TOS 介面偵測成功，開始執行... 標的：' + symbol);

    // 清除 sessionStorage，避免重複執行
    sessionStorage.removeItem('cd_symbol');
    sessionStorage.removeItem('cd_trade');
    sessionStorage.removeItem('cd_expiry');

    // 顯示提示卡並執行
    if (trade && expiry) showTradingHelper(symbol, trade, expiry);
    executeTradeFlow(symbol, trade, expiry);

  }, 500); // 每 0.5 秒偵測一次

})();

// ─── 等待特定 DOM 元素出現 ────────────────────────────────────────────────────
function waitForElement(selectors, maxWait = 15000) {
  return new Promise((resolve, reject) => {
    let elapsed = 0;
    const timer = setInterval(() => {
      const el = document.querySelector(selectors);
      if (el) { clearInterval(timer); resolve(el); }
      elapsed += 500;
      if (elapsed >= maxWait) {
        clearInterval(timer);
        reject('Timeout: ' + selectors);
      }
    }, 500);
  });
}

function delay(ms) { return new Promise(r => setTimeout(r, ms)); }

// ─── 核心下單流程 ─────────────────────────────────────────────────────────────
async function executeTradeFlow(symbol, trade, expiry) {
  const SYMBOL_INPUT = [
    'input[placeholder*="Symbol"]',
    'input[placeholder*="symbol"]',
    'input[placeholder*="代號"]',
    '[data-testid="symbol-input"]',
    'input[aria-label*="Symbol"]'
  ].join(', ');

  try {
    updateHelperStatus('⏳ 填入標的中...');

    // 階段 1：填入標的
    const inputBox = await waitForElement(SYMBOL_INPUT);
    inputBox.focus();
    await delay(300);
    // 清空後填入（React controlled input 需要這樣）
    const nativeInputValueSetter = Object.getOwnPropertyDescriptor(window.HTMLInputElement.prototype, 'value').set;
    nativeInputValueSetter.call(inputBox, symbol);
    inputBox.dispatchEvent(new Event('input',  { bubbles: true }));
    inputBox.dispatchEvent(new Event('change', { bubbles: true }));
    await delay(1000);
    inputBox.dispatchEvent(new KeyboardEvent('keydown', { key: 'Enter', keyCode: 13, bubbles: true }));
    const form = inputBox.closest('form');
    if (form) form.dispatchEvent(new Event('submit', { bubbles: true, cancelable: true }));
    console.log('🕊️ 標的送出：' + symbol);

    if (!trade || !expiry) {
      updateHelperStatus('✅ 標的已填入');
      return;
    }

    // 階段 2：展開選擇權鏈
    updateHelperStatus('⏳ 展開選擇權鏈...');
    const chainBtn = await waitForElement(
      'button[aria-label="顯示期權鏈"], button[aria-label="Show Options Chain"], button[aria-label="Options Chain"], [data-testid="options-chain-button"]'
    );
    if (chainBtn.getAttribute('aria-expanded') !== 'true') {
      chainBtn.click();
      await delay(1500);
    }

    // 階段 3：找到期日並展開
    updateHelperStatus('⏳ 尋找到期日 ' + expiry + '...');
    const dateParts = expiry.split('-');
    const year  = dateParts[0];
    const month = parseInt(dateParts[1], 10);
    const day   = parseInt(dateParts[2], 10);
    const targetDateStr = `${year}年${month}月${day}日`;

    await waitForElement('button[data-testid="expiration-row-expand-button"]');
    await delay(500);
    const dateBtns = document.querySelectorAll('button[data-testid="expiration-row-expand-button"]');
    let targetDateBtn = null;
    for (const btn of dateBtns) {
      if (btn.innerText.includes(targetDateStr)) { targetDateBtn = btn; break; }
    }
    if (!targetDateBtn) {
      updateHelperStatus('⚠️ 找不到到期日 ' + expiry + '，請手動選擇');
      return;
    }
    if (targetDateBtn.getAttribute('aria-expanded') !== 'true') {
      targetDateBtn.scrollIntoView({ behavior: 'smooth', block: 'center' });
      await delay(600);
      targetDateBtn.click();
      await delay(2500);
    }

    // 階段 4：逐腳位點擊
    updateHelperStatus('⏳ 填入腳位...');
    const legs = trade.split('/').map(t => t.trim());
    await delay(3000);

    for (let i = 0; i < legs.length; i++) {
      const parts       = legs[i].split(' ').filter(p => p);
      const action      = parts[0].toUpperCase();
      const type        = parts[1].toUpperCase();
      const strike      = parseFloat(parts[2]);
      const typeClass   = type   === 'PUT'  ? '.cell.put'  : '.cell.call';
      const actionClass = action === 'SELL' ? '.bid'       : '.ask';

      const selectors = [
        `td${typeClass}${actionClass}[data-testid^="data-cell-td-${strike}-"]`,
        `td${typeClass}${actionClass}[data-testid^="data-cell-td-${strike.toFixed(1)}-"]`,
        `td${typeClass}${actionClass}[data-testid^="data-cell-td-${strike.toFixed(0)}-"]`,
        `td${typeClass}[data-testid^="data-cell-td-${strike}-"]`
      ];

      let cell = null;
      for (const sel of selectors) { cell = document.querySelector(sel); if (cell) break; }

      if (cell) {
        cell.scrollIntoView({ behavior: 'smooth', block: 'center', inline: 'center' });
        await delay(800);
        const btn = cell.querySelector('button');
        if (btn) {
          const opts = { bubbles: true, cancelable: true, ctrlKey: i > 0, view: window, which: 1 };
          btn.dispatchEvent(new PointerEvent('pointerdown', opts));
          btn.dispatchEvent(new MouseEvent('mousedown',    opts));
          await delay(120);
          btn.dispatchEvent(new PointerEvent('pointerup', opts));
          btn.dispatchEvent(new MouseEvent('mouseup',     opts));
          btn.click();
          console.log('🕊️ 點擊：' + legs[i]);
          await delay(1200);
        }
      } else {
        updateHelperStatus('⚠️ 找不到 ' + type + ' ' + strike + '，請手動點擊');
        console.error('🕊️ 找不到腳位：' + type + ' ' + strike);
      }
    }

    updateHelperStatus('✅ 完成！請確認訂單後送出');
    console.log('🕊️ 所有腳位完成！');

  } catch(e) {
    updateHelperStatus('⚠️ 中斷：' + e + ' — 請手動操作');
    console.error('🕊️ 流程中斷：', e);
  }
}

// ─── 右下角提示卡 ─────────────────────────────────────────────────────────────
function showTradingHelper(symbol, trade, expiry) {
  const existing = document.getElementById('chilldove-helper');
  if (existing) existing.remove();

  const helper = document.createElement('div');
  helper.id = 'chilldove-helper';
  const formattedTrade = trade.replace(/\//g, '<br>👉 ');

  helper.innerHTML = `
    <div style="font-family:'Segoe UI',sans-serif;background:#0f172a;border:2px solid #01696f;border-radius:14px;padding:20px;color:white;box-shadow:0 10px 40px rgba(0,0,0,0.8);width:300px">
      <div style="display:flex;justify-content:space-between;align-items:center;border-bottom:1px solid #334155;padding-bottom:10px;margin-bottom:14px">
        <h3 style="margin:0;color:#01696f;font-size:14px;font-weight:700">🕊️ 下班鴿帶單助手</h3>
        <button id="cd-close-x" style="background:none;border:none;color:#64748b;cursor:pointer;font-size:18px;padding:0">×</button>
      </div>
      <p style="margin:0 0 4px;font-size:12px;color:#94a3b8">標的：<strong style="color:white;font-size:16px">${symbol}</strong></p>
      <p style="margin:0 0 12px;font-size:12px;color:#94a3b8">到期：<strong style="color:#fcd34d">${expiry}</strong></p>
      <div style="background:#1e293b;padding:12px;border-radius:8px;border-left:3px solid #01696f;margin-bottom:12px">
        <p style="margin:0;font-size:13px;font-weight:700;color:#a7f3d0;line-height:1.7;font-family:monospace">👉 ${formattedTrade}</p>
      </div>
      <div id="cd-status" style="font-size:11px;color:#fbbf24;text-align:center;margin-bottom:12px">⏳ 等待 TOS 介面載入...</div>
      <button id="cd-close-btn" style="width:100%;padding:8px;background:#1e3a3a;border:1px solid #01696f;color:#a7f3d0;border-radius:6px;cursor:pointer;font-weight:600;font-size:12px">
        ✅ 已確認下單（關閉）
      </button>
    </div>`;

  helper.style.cssText = 'position:fixed;bottom:30px;right:30px;z-index:99999999';
  document.body.appendChild(helper);
  document.getElementById('cd-close-btn').onclick = () => helper.remove();
  document.getElementById('cd-close-x').onclick   = () => helper.remove();
}

function updateHelperStatus(msg) {
  const el = document.getElementById('cd-status');
  if (!el) return;
  const isOk  = msg.startsWith('✅');
  const isWarn= msg.startsWith('⚠️');
  el.textContent = msg;
  el.style.color = isOk ? '#34d399' : isWarn ? '#f87171' : '#fbbf24';
}
